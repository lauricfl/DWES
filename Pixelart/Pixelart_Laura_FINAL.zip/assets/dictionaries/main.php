<?php
$dict = array(
  "titulo" => "P1X3L4RT",
  "direccion_css" => ".assets/css/styles.css",
  "celda" => "celda",
  'form_id' => 'datos',
  'form_destination' => './index.php?action=add',
  'id_input' => 'color',
  'id_div_form' => 'colorDiv',
  'name_input' => 'inputcolor',
  'id_boton' => 'boton',
  'id_inputCoord'=>"inputCoord",
  'id_tablero' => 'tablero',
  'txt_color' => "Confirmar color",
  'id_div_color' => "divColor",
  'id_coord' => "coordenadas",
  "direccion_css" => '<link rel="stylesheet" href="./assets/css/styles.css"/>',
  'script_js' => '<script src="./assets/javascript/tablero.js"></script>',
  'script_tag_jquery' => '<script type="text/javascript"
    src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>',
  'script_tag_js' => '<script type="text/javascript" src="./assets/javascript/validar.js"></script>',
  'script_load_page' => '<script>console.log("Página recargada");</script>',
  'link_bootstrap' => '<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65"
    crossorigin="anonymous"/>',
  'script_bootstrap' => '<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
    crossorigin="anonymous"></script>',
);
