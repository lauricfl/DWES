<?php
/**
 * Constante que define el HOST de la base de datos
 */
define("HOST", "db5011945048.hosting-data.io");
/**
 * Constante que define el USUARIO para la base de datos
 */
define("USER", "dbu2571704");
/**
 * Constante que define el PASSWORD para la base de datos
 */
define("PASSWORD", "p1x3l4rt_DWES#22@23");
/**
 * Constante que define el NOMBRE de la base de datos
 */
define("DB", "dbs10057814");
/**
 * Constante que define con qué tipo de base de datos se va a trabajar
 */
define("DRIVER", "mysql");
/**
 * Constante que define el USUARIO para la base de datos
 */
define("PORT", "3306");
/**
 * Constante que define el acceso a la base de datos con PDO
 */
define("DSN", DRIVER . ':host=' . HOST . ';dbname=' . DB);

